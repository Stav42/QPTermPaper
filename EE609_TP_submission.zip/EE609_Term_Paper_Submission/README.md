# QPTermPaper

## Term Paper codes for EE609

**Requirements**: You should have **conda** package installed in your system.

Follow the steps given below to run the code:

Setup Environment:

1. conda create --name {environement_name}

2. conda install --file requirements.txt -c conda-forge

3. cd EE609_Term_Paper_Submission

Run SVM:

1. cd SVM

2. python iris_svm.py

Run MPC:

1. cd MPC

2. python cart_pendulum.py


