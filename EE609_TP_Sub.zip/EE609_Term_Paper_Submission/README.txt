# QPTermPaper

## Term Paper codes for EE609

All the codes for the implemenetd solvers and their applications are included in the EE609_TP_submission.zip

We faced problems while installing necessary libraries like scikit-sparse due to their use of deprecated libraries. So, we have done all our implementations using conda package.

**Requirements**: You should have **conda** package installed in your system.

In order to install conda, follow this link: https://docs.anaconda.com/free/anaconda/install/

Follow the steps given below to run the code: 

Setup Environment:

1. conda create --name {env_name}

2. conda activate {env_name}

3. conda install --file requirements.txt -c conda-forge

In order to install qpSWIFT that we have used as IPM solver, run the below commands:

1. git clone https://github.com/qpSWIFT/qpSWIFT.git

2. cd qpSWIFT/python

3. python setup.py install

4. cd ../../

To run SVM:

1. cd SVM

2. python iris_svm.py

To run MPC:

1. cd MPC

2. python cart_pendulum.py


